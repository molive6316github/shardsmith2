New
+21
-0

export default function TermsPage() {
  return (
    <main className="min-h-screen bg-parchment">
      <div className="mx-auto max-w-3xl px-6 py-16 space-y-6">
        <a href="/" className="text-sm font-semibold text-slate-600">
          ← Back to generator
        </a>
        <h1 className="font-display text-3xl">Terms of Service</h1>
        <p className="text-slate-600">
          ShardSmith provides procedural content for tabletop roleplaying games.
          Content is provided as-is without warranty. You are responsible for how
          you use generated content in your campaigns.
        </p>
        <p className="text-slate-600">
          Subscriptions renew monthly until canceled. You can manage or cancel
          your subscription at any time through the billing portal.
        </p>
      </div>
    </main>
  );
}