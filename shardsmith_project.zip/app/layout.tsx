New
+55
-0

import "./globals.css";
import type { Metadata } from "next";
import { Cinzel, Inter } from "next/font/google";

const cinzel = Cinzel({
  subsets: ["latin"],
  variable: "--font-cinzel",
  display: "swap",
});

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap",
});

export const metadata: Metadata = {
  title: "ShardSmith — D&D Content Generator",
  description: "Generate NPCs, prophecies, and loot with a single click.",
  metadataBase: new URL(process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000"),
  openGraph: {
    title: "ShardSmith — D&D Content Generator",
    description: "NPCs, prophecies, and loot for your next adventure.",
    url: "/",
    siteName: "ShardSmith",
    images: [
      {
        url: "/og.svg",
        width: 1200,
        height: 630,
        alt: "ShardSmith preview",
      },
    ],
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "ShardSmith — D&D Content Generator",
    description: "NPCs, prophecies, and loot for your next adventure.",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className={`${cinzel.variable} ${inter.variable}`}>
      <body className="min-h-screen bg-parchment text-ink">
        {children}
      </body>
    </html>
  );
}