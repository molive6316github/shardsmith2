New
+90
-0

import { NextRequest, NextResponse } from "next/server";
import { generateContent, type GeneratorType, type Tone } from "../../../lib/generator";
import { checkRateLimit } from "../../../lib/rateLimiter";
import { supabaseAdmin } from "../../../lib/supabaseAdmin";

const FREE_LIMIT = 10;

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const type = body.type as GeneratorType;
    const tone = body.tone as Tone;
    const profanityFilter = Boolean(body.profanityFilter);
    const seedOverride = body.seed as string | null;

    if (!type || !tone) {
      return NextResponse.json({ message: "Missing generator settings." }, { status: 400 });
    }

    const authHeader = request.headers.get("authorization");
    const token = authHeader?.replace("Bearer ", "");
    let userId: string | null = null;
    let isPro = false;

    if (token) {
      const { data } = await supabaseAdmin.auth.getUser(token);
      userId = data.user?.id ?? null;
    }

    if (userId) {
      const { data: profile } = await supabaseAdmin
        .from("profiles")
        .select("is_pro")
        .eq("id", userId)
        .maybeSingle();
      isPro = profile?.is_pro ?? false;
    }

    let deviceId = request.cookies.get("device_id")?.value ?? null;
    if (!deviceId) {
      deviceId = crypto.randomUUID();
    }

    if (!isPro) {
      const key = userId ? `user:${userId}` : `device:${deviceId}`;
      const limit = await checkRateLimit(key, FREE_LIMIT);
      if (!limit.allowed) {
        return NextResponse.json(
          { message: "Free tier limit reached. Upgrade to Pro for unlimited access." },
          { status: 429 }
        );
      }
    }

    const seed = seedOverride || `${Date.now()}-${userId ?? deviceId}`;
    const result = generateContent({
      type,
      tone,
      profanityFilter,
      seed,
    });

    if (isPro && userId) {
      await supabaseAdmin.from("generations").insert({
        user_id: userId,
        type,
        tone,
        content: result.content,
        seed: result.seed,
      });
    }

    const response = NextResponse.json({ result });
    if (!request.cookies.get("device_id")) {
      response.cookies.set("device_id", deviceId, {
        httpOnly: true,
        sameSite: "lax",
        maxAge: 60 * 60 * 24 * 365,
        path: "/",
      });
    }

    return response;
  } catch (error) {
    return NextResponse.json(
      { message: "Unable to generate content right now." },
      { status: 500 }
    );
  }
}