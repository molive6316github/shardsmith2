New
+6
-0

module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
};