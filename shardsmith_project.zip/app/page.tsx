New
+41
-0

import GeneratorApp from "../components/GeneratorApp";

export default function HomePage() {
  return (
    <main className="min-h-screen">
      <section className="gradient-banner">
        <div className="mx-auto max-w-6xl px-6 py-12">
          <nav className="flex items-center justify-between text-sm font-semibold">
            <span className="font-display text-2xl">ShardSmith</span>
            <div className="flex gap-4 text-slate-600">
              <a href="/privacy" className="hover:text-ink">
                Privacy
              </a>
              <a href="/terms" className="hover:text-ink">
                Terms
              </a>
              <a href="/account" className="hover:text-ink">
                Account
              </a>
            </div>
          </nav>
          <div className="mt-12 space-y-4">
            <p className="badge">Micro-SaaS</p>
            <h1 className="font-display text-4xl md:text-5xl text-ink">
              Forge rich D&D content in seconds.
            </h1>
            <p className="max-w-2xl text-lg text-slate-600">
              ShardSmith crafts NPCs, prophecies, and loot using curated tables and
              deterministic seeds. Keep things fast, flavorful, and always ready
              for the table.
            </p>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-6 pb-20">
        <GeneratorApp />
      </section>
    </main>
  );
}