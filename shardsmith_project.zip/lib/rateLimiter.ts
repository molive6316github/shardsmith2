New
+47
-0

import { Redis } from "@upstash/redis";

const memoryStore = new Map<string, { count: number; resetAt: number }>();

function getResetAt() {
  const now = new Date();
  const reset = new Date(now);
  reset.setUTCHours(24, 0, 0, 0);
  return reset.getTime();
}

export async function checkRateLimit(key: string, limit: number) {
  const redisUrl = process.env.UPSTASH_REDIS_REST_URL;
  const redisToken = process.env.UPSTASH_REDIS_REST_TOKEN;

  if (redisUrl && redisToken) {
    const redis = new Redis({ url: redisUrl, token: redisToken });
    const dateKey = new Date().toISOString().slice(0, 10);
    const redisKey = `shardsmith:limit:${dateKey}:${key}`;
    const count = await redis.incr(redisKey);
    if (count === 1) {
      const resetSeconds = Math.floor((getResetAt() - Date.now()) / 1000);
      await redis.expire(redisKey, resetSeconds);
    }
    return {
      allowed: count <= limit,
      remaining: Math.max(limit - count, 0),
      resetAt: getResetAt(),
    };
  }

  const now = Date.now();
  const existing = memoryStore.get(key);
  if (!existing || existing.resetAt < now) {
    const resetAt = getResetAt();
    memoryStore.set(key, { count: 1, resetAt });
    return { allowed: true, remaining: limit - 1, resetAt };
  }

  existing.count += 1;
  memoryStore.set(key, existing);
  return {
    allowed: existing.count <= limit,
    remaining: Math.max(limit - existing.count, 0),
    resetAt: existing.resetAt,
  };
}