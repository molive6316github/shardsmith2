New
+43
-0

create extension if not exists "pgcrypto";

create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  is_pro boolean not null default false,
  stripe_customer_id text,
  stripe_subscription_id text,
  created_at timestamptz default now()
);

alter table profiles enable row level security;

create policy "Profiles are viewable by owner" on profiles
  for select
  using (auth.uid() = id);

create policy "Profiles are insertable by owner" on profiles
  for insert
  with check (auth.uid() = id);

create policy "Profiles are updatable by owner" on profiles
  for update
  using (auth.uid() = id);

create table if not exists generations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  type text not null,
  tone text not null,
  content text not null,
  seed text not null,
  created_at timestamptz default now()
);

alter table generations enable row level security;

create policy "Generations are viewable by owner" on generations
  for select
  using (auth.uid() = user_id);

create policy "Generations are insertable by owner" on generations
  for insert
  with check (auth.uid() = user_id);