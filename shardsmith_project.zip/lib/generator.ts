New
+254
-0

import { applyProfanityFilter } from "./profanity";
import { hashString, mulberry32, pick, pickWeighted } from "./random";

export type Tone = "Classic Fantasy" | "Dark" | "Comedic" | "Epic";
export type GeneratorType = "npc" | "prophecy" | "loot";

const tones: Record<Tone, { adjectives: string[]; moods: string[]; twists: string[] }> = {
  "Classic Fantasy": {
    adjectives: ["honorable", "weathered", "wise", "restless", "noble", "wandering"],
    moods: ["warm", "quiet", "steadfast", "hopeful"],
    twists: ["a forgotten oath", "a royal debt", "a faded map", "an old rivalry"],
  },
  Dark: {
    adjectives: ["grim", "hollow-eyed", "bloodstained", "ashen", "merciless", "cursed"],
    moods: ["somber", "foreboding", "uneasy", "bleak"],
    twists: ["a buried crime", "a whispered bargain", "a cursed relic", "a doomed pact"],
  },
  Comedic: {
    adjectives: ["scatterbrained", "overconfident", "boastful", "quirky", "dramatic"],
    moods: ["playful", "chaotic", "bright", "absurd"],
    twists: ["a misplaced heirloom", "a rival prank", "a ridiculous prophecy", "an unpaid tab"],
  },
  Epic: {
    adjectives: ["legend-bound", "radiant", "storm-forged", "unyielding", "mythic"],
    moods: ["awe-inspiring", "intense", "resolute", "fateful"],
    twists: ["a celestial omen", "a shattered crown", "a dragon's vow", "a world-shaping choice"],
  },
};

const npcRoles = [
  "caravan scout",
  "temple archivist",
  "tavern keeper",
  "arcane cartographer",
  "retired blade",
  "smuggler turned informant",
  "village healer",
  "court envoy",
  "bounty broker",
  "clockwork artisan",
];

const npcPersonality = [
  "speaks in short, clipped phrases",
  "collects small charms and insists each has a story",
  "laughs too loudly at their own jokes",
  "keeps a ledger of every favor owed",
  "never sits with their back to a door",
  "always smells faintly of incense",
  "pauses before answering as if weighing a prophecy",
  "sings under their breath when nervous",
];

const npcSecrets = [
  "secretly works for a rival faction",
  "owes a life-debt to a dangerous figure",
  "is hiding a stolen relic",
  "is the last heir of a fallen house",
  "once betrayed a traveling companion",
  "is cursed to forget every sunrise",
  "has been bribing city guards",
];

const npcHooks = [
  "asks the party to escort a sealed letter",
  "offers a map to a ruin for a modest fee",
  "needs help breaking a friend out of jail",
  "begs the party to recover a lost family blade",
  "insists the party is tied to an old prophecy",
  "wants a rare herb gathered before moonrise",
  "needs witnesses for a dangerous negotiation",
];

const prophecyOpeners = [
  "When the first bell cracks",
  "Under a moon of ash",
  "At the edge of the last harvest",
  "When the river runs backward",
  "On the day the statues sing",
  "When the iron star falls",
  "At the ninth turning of the key",
];

const prophecyLines = [
  "the hidden blade will choose its keeper",
  "a crown of salt will weigh on the unworthy",
  "the orphaned flame will name a champion",
  "three shadows will barter for daylight",
  "the silent gate will open for a liar",
  "the shattered pact will demand a price",
  "a city will sleep beneath the sea",
  "the loyal beast will devour its master",
];

const prophecyClosers = [
  "only the humble may break the chain",
  "and the north wind will keep the secret",
  "but mercy will taste like iron",
  "and the chorus will call for sacrifice",
  "yet the smallest hand may hold the dusk",
  "and the true name will be forgotten",
];

const lootNames = [
  "Whisperglass Dagger",
  "Lantern of Quiet Steps",
  "Copperleaf Mantle",
  "Seamstress of Sparks",
  "Starbound Compass",
  "Briar-etched Locket",
  "Griffon's Mirth Mug",
  "Sablethorn Ring",
  "Stormtide Flask",
  "Echoed Warhorn",
];

const lootRarities = [
  { value: "Common", weight: 40 },
  { value: "Uncommon", weight: 30 },
  { value: "Rare", weight: 20 },
  { value: "Very Rare", weight: 8 },
  { value: "Legendary", weight: 2 },
];

const lootQuirks = [
  "hums softly when danger nears",
  "smells like rain after battle",
  "glows faintly near hidden doors",
  "sheds cool mist at dawn",
  "refuses to get dirty",
  "echoes the last spoken word",
  "turns lukewarm drinks icy",
  "shakes when dragons are near",
];

const lootMechanics = [
  "Once per day, you can reroll a failed Dexterity check.",
  "You gain advantage on stealth checks in heavy rain.",
  "While carried, you ignore difficult terrain from ice or snow.",
  "You can cast " +
    "light once per short rest, the light taking a color you choose.",
  "You can speak and understand one additional language while attuned.",
  "After a long rest, choose a damage type; you gain resistance to it for 1 hour.",
  "When you roll initiative, you gain temporary hit points equal to your proficiency bonus.",
];

const npcNamePools = {
  first: [
    "Eira",
    "Bram",
    "Thalia",
    "Kael",
    "Orin",
    "Lysa",
    "Garrik",
    "Seren",
    "Mira",
    "Dain",
  ],
  last: [
    "Ashwalker",
    "Ravenhart",
    "Stormveil",
    "Brightwell",
    "Ironmark",
    "Duskwhisper",
    "Oakrender",
    "Cinderlane",
    "Mistbrook",
    "Goldriver",
  ],
};

export type GeneratedResult = {
  seed: string;
  type: GeneratorType;
  tone: Tone;
  content: string;
};

export function generateContent({
  type,
  tone,
  profanityFilter,
  seed,
}: {
  type: GeneratorType;
  tone: Tone;
  profanityFilter: boolean;
  seed: string;
}): GeneratedResult {
  const toneSet = tones[tone];
  const rng = mulberry32(hashString(seed));

  let content = "";

  if (type === "npc") {
    const name = `${pick(rng, npcNamePools.first)} ${pick(rng, npcNamePools.last)}`;
    const role = pick(rng, npcRoles);
    const personality = pick(rng, npcPersonality);
    const secret = pick(rng, npcSecrets);
    const hook = pick(rng, npcHooks);
    const adjective = pick(rng, toneSet.adjectives);
    content = [
      `Name: ${name}`,
      `Role: ${adjective} ${role}`,
      `Personality: ${personality}`,
      `Secret: ${secret}`,
      `Hook: ${hook}`,
    ].join("\n");
  }

  if (type === "prophecy") {
    const lineCount = pick(rng, [4, 5, 6, 7, 8]);
    const lines = Array.from({ length: lineCount }, (_, index) => {
      if (index === 0) {
        return `${pick(rng, prophecyOpeners)},`;
      }
      if (index === lineCount - 1) {
        return `${pick(rng, prophecyClosers)}.`;
      }
      return `${pick(rng, prophecyLines)},`;
    });

    const twist = pick(rng, toneSet.twists);
    content = lines
      .map((line, index) => (index === lines.length - 2 ? `${line} ${twist}` : line))
      .join("\n");
  }

  if (type === "loot") {
    const name = pick(rng, lootNames);
    const rarity = pickWeighted(rng, lootRarities);
    const quirk = pick(rng, lootQuirks);
    const mechanic = pick(rng, lootMechanics);
    const mood = pick(rng, toneSet.moods);
    content = [
      `Item: ${name}`,
      `Rarity: ${rarity}`,
      `Quirk: ${quirk}`,
      `Minor Mechanic: ${mechanic}`,
      `Vibe: ${mood}`,
    ].join("\n");
  }

  content = applyProfanityFilter(content, profanityFilter);

  return {
    seed,
    type,
    tone,
    content,
  };
}