New
+21
-0

export default function PrivacyPage() {
  return (
    <main className="min-h-screen bg-parchment">
      <div className="mx-auto max-w-3xl px-6 py-16 space-y-6">
        <a href="/" className="text-sm font-semibold text-slate-600">
          ← Back to generator
        </a>
        <h1 className="font-display text-3xl">Privacy Policy</h1>
        <p className="text-slate-600">
          ShardSmith stores your email and subscription status when you choose to
          create an account. We store generation history only for Pro users. We
          do not sell your data.
        </p>
        <p className="text-slate-600">
          Anonymous usage is tracked via a device identifier cookie to enforce
          the free tier rate limit. Payments are handled securely by Stripe.
        </p>
      </div>
    </main>
  );
}