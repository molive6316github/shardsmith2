New
+123
-0

"use client";

import { useEffect, useState } from "react";
import { supabaseClient } from "../lib/supabaseClient";
import type { Profile } from "../lib/types";

export default function AccountPanel() {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState("");

  useEffect(() => {
    const loadProfile = async () => {
      const { data } = await supabaseClient.auth.getSession();
      const user = data.session?.user;
      if (!user) return;

      const { data: profileData } = await supabaseClient
        .from("profiles")
        .select("id,is_pro,stripe_customer_id,stripe_subscription_id")
        .eq("id", user.id)
        .maybeSingle();

      if (!profileData) {
        const { data: inserted } = await supabaseClient
          .from("profiles")
          .insert({ id: user.id })
          .select("id,is_pro,stripe_customer_id,stripe_subscription_id")
          .single();
        setProfile(inserted ?? null);
        return;
      }

      setProfile(profileData);
    };

    loadProfile();
  }, []);

  const handleLogin = async () => {
    setStatus("");
    const { error } = await supabaseClient.auth.signInWithOtp({
      email,
      options: {
        emailRedirectTo: `${window.location.origin}/account`,
      },
    });

    if (error) {
      setStatus(error.message);
      return;
    }

    setStatus("Magic link sent. Check your inbox.");
  };

  const handlePortal = async () => {
    const { data } = await supabaseClient.auth.getSession();
    const token = data.session?.access_token;
    const response = await fetch("/api/stripe/portal", {
      method: "POST",
      headers: token ? { Authorization: `Bearer ${token}` } : undefined,
    });
    const payload = await response.json();
    if (!response.ok) {
      setStatus(payload.message || "Unable to open portal.");
      return;
    }
    window.location.href = payload.url;
  };

  return (
    <div className="card p-6 space-y-4">
      <h2 className="font-display text-2xl">Account</h2>
      {!profile && (
        <div className="space-y-3">
          <p className="text-sm text-slate-600">
            Sign in to manage your subscription and history.
          </p>
          <input
            className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3"
            placeholder="you@example.com"
            value={email}
            onChange={(event) => setEmail(event.target.value)}
          />
          <button
            type="button"
            className="w-full rounded-xl bg-ink px-4 py-3 text-white font-semibold"
            onClick={handleLogin}
          >
            Send magic link
          </button>
        </div>
      )}

      {profile && (
        <div className="space-y-3">
          <p className="text-sm text-slate-600">
            Status: {profile.is_pro ? "Pro" : "Free"}
          </p>
          {profile.is_pro && (
            <button
              type="button"
              className="w-full rounded-xl border border-slate-200 px-4 py-3 font-semibold"
              onClick={handlePortal}
            >
              Manage subscription
            </button>
          )}
          <button
            type="button"
            className="w-full rounded-xl border border-slate-200 px-4 py-3 font-semibold"
            onClick={() => supabaseClient.auth.signOut()}
          >
            Sign out
          </button>
        </div>
      )}

      {status && <p className="text-sm text-amber-700">{status}</p>}
    </div>
  );
}