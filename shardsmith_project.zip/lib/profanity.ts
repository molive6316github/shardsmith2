New
+21
-0

const banned = [
  "damn",
  "hell",
  "bastard",
  "bloody",
  "crap",
  "shit",
  "fuck",
  "ass",
  "bitch",
];

export function applyProfanityFilter(text: string, enabled: boolean) {
  if (!enabled) return text;
  let filtered = text;
  for (const word of banned) {
    const regex = new RegExp(`\\b${word}\\b`, "gi");
    filtered = filtered.replace(regex, "—");
  }
  return filtered;
}