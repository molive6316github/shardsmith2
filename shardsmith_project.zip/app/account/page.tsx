New
+14
-0

import AccountPanel from "../../components/AccountPanel";

export default function AccountPage() {
  return (
    <main className="min-h-screen bg-parchment">
      <div className="mx-auto max-w-3xl px-6 py-16 space-y-6">
        <a href="/" className="text-sm font-semibold text-slate-600">
          ← Back to generator
        </a>
        <AccountPanel />
      </div>
    </main>
  );
}