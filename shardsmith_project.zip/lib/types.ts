New
+18
-0

import type { GeneratorType, Tone } from "./generator";

export type Profile = {
  id: string;
  is_pro: boolean;
  stripe_customer_id: string | null;
  stripe_subscription_id: string | null;
};

export type Generation = {
  id: string;
  user_id: string;
  type: GeneratorType;
  tone: Tone;
  content: string;
  seed: string;
  created_at: string;
};