New
+451
-0

"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import clsx from "clsx";
import { supabaseClient } from "../lib/supabaseClient";
import type { Generation, Profile } from "../lib/types";
import type { GeneratorType, Tone } from "../lib/generator";

const tones: Tone[] = ["Classic Fantasy", "Dark", "Comedic", "Epic"];
const generatorTypes: { label: string; value: GeneratorType }[] = [
  { label: "NPC", value: "npc" },
  { label: "Prophecy", value: "prophecy" },
  { label: "Loot", value: "loot" },
];

function buildDownload(content: string) {
  const blob = new Blob([content], { type: "text/plain" });
  return URL.createObjectURL(blob);
}

export default function GeneratorApp() {
  const [tone, setTone] = useState<Tone>("Classic Fantasy");
  const [generatorType, setGeneratorType] = useState<GeneratorType>("npc");
  const [result, setResult] = useState<string>("");
  const [seed, setSeed] = useState<string>("");
  const [isLoading, setIsLoading] = useState(false);
  const [profanityFilter, setProfanityFilter] = useState(true);
  const [sessionUserId, setSessionUserId] = useState<string | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [history, setHistory] = useState<Generation[]>([]);
  const [statusMessage, setStatusMessage] = useState<string>("");
  const [email, setEmail] = useState("");

  const isPro = profile?.is_pro ?? false;

  const fetchProfile = useCallback(async (userId: string) => {
    const { data, error } = await supabaseClient
      .from("profiles")
      .select("id,is_pro,stripe_customer_id,stripe_subscription_id")
      .eq("id", userId)
      .maybeSingle();

    if (error) {
      setStatusMessage("We couldn't load your profile. Try refreshing.");
      return;
    }

    if (!data) {
      const { data: inserted } = await supabaseClient
        .from("profiles")
        .insert({ id: userId })
        .select("id,is_pro,stripe_customer_id,stripe_subscription_id")
        .single();
      setProfile(inserted ?? null);
      return;
    }

    setProfile(data);
  }, []);

  const fetchHistory = useCallback(async () => {
    const { data } = await supabaseClient.auth.getSession();
    const token = data.session?.access_token;
    if (!token) return;

    const response = await fetch("/api/history", {
      headers: { Authorization: `Bearer ${token}` },
    });

    if (!response.ok) return;
    const payload = (await response.json()) as { history: Generation[] };
    setHistory(payload.history);
  }, []);

  useEffect(() => {
    const loadSession = async () => {
      const { data } = await supabaseClient.auth.getSession();
      const userId = data.session?.user.id ?? null;
      setSessionUserId(userId);
      if (userId) {
        await fetchProfile(userId);
      }
    };

    loadSession();

    const { data: subscription } = supabaseClient.auth.onAuthStateChange(
      async (_event, session) => {
        const userId = session?.user.id ?? null;
        setSessionUserId(userId);
        if (userId) {
          await fetchProfile(userId);
          await fetchHistory();
        } else {
          setProfile(null);
          setHistory([]);
        }
      }
    );

    return () => subscription.subscription.unsubscribe();
  }, [fetchHistory, fetchProfile]);

  useEffect(() => {
    if (isPro) {
      fetchHistory();
    }
  }, [fetchHistory, isPro]);

  const handleGenerate = useCallback(
    async (seedOverride?: string) => {
      setIsLoading(true);
      setStatusMessage("");
      const { data } = await supabaseClient.auth.getSession();
      const token = data.session?.access_token;
      const response = await fetch("/api/generate", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({
          type: generatorType,
          tone,
          profanityFilter,
          seed: seedOverride ?? null,
        }),
      });

      const payload = await response.json();
      if (!response.ok) {
        setStatusMessage(payload.message || "Something went wrong.");
        setIsLoading(false);
        return;
      }

      setResult(payload.result.content);
      setSeed(payload.result.seed);
      if (isPro) {
        await fetchHistory();
      }
      setIsLoading(false);
    },
    [fetchHistory, generatorType, isPro, profanityFilter, tone]
  );

  const handleCopy = async () => {
    if (!result) return;
    await navigator.clipboard.writeText(result);
    setStatusMessage("Copied to clipboard.");
  };

  const handleDownload = () => {
    if (!result) return;
    const url = buildDownload(result);
    const link = document.createElement("a");
    link.href = url;
    link.download = `shardsmith-${generatorType}.txt`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleLogin = async () => {
    setStatusMessage("");
    const { error } = await supabaseClient.auth.signInWithOtp({
      email,
      options: {
        emailRedirectTo: `${window.location.origin}/account`,
      },
    });

    if (error) {
      setStatusMessage(error.message);
      return;
    }

    setStatusMessage("Magic link sent. Check your inbox.");
  };

  const handleUpgrade = async () => {
    setStatusMessage("");
    const { data } = await supabaseClient.auth.getSession();
    const token = data.session?.access_token;

    const response = await fetch("/api/stripe/checkout", {
      method: "POST",
      headers: token ? { Authorization: `Bearer ${token}` } : undefined,
    });

    const payload = await response.json();
    if (!response.ok) {
      setStatusMessage(payload.message || "Unable to start checkout.");
      return;
    }

    window.location.href = payload.url;
  };

  const handlePortal = async () => {
    setStatusMessage("");
    const { data } = await supabaseClient.auth.getSession();
    const token = data.session?.access_token;

    const response = await fetch("/api/stripe/portal", {
      method: "POST",
      headers: token ? { Authorization: `Bearer ${token}` } : undefined,
    });

    const payload = await response.json();
    if (!response.ok) {
      setStatusMessage(payload.message || "Unable to open billing portal.");
      return;
    }

    window.location.href = payload.url;
  };

  const regenerateLabel = useMemo(() => {
    if (!seed) return "Generate";
    return isLoading ? "Forging..." : "Regenerate";
  }, [isLoading, seed]);

  return (
    <div className="grid gap-8 lg:grid-cols-[1.2fr_0.8fr]">
      <section className="space-y-6">
        <div className="card p-6 space-y-6">
          <div>
            <p className="badge">Generator</p>
            <div className="segmented mt-4">
              {generatorTypes.map((item) => (
                <button
                  key={item.value}
                  type="button"
                  data-active={generatorType === item.value}
                  onClick={() => setGeneratorType(item.value)}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <label className="space-y-2 text-sm font-semibold">
              Tone
              <select
                className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3"
                value={tone}
                onChange={(event) => setTone(event.target.value as Tone)}
              >
                {tones.map((option) => (
                  <option key={option} value={option}>
                    {option}
                  </option>
                ))}
              </select>
            </label>

            <label className="space-y-2 text-sm font-semibold">
              Profanity filter
              <div className="flex items-center gap-3">
                <label className="toggle">
                  <input
                    type="checkbox"
                    checked={profanityFilter}
                    onChange={() => setProfanityFilter((prev) => !prev)}
                  />
                  <span className="relative"></span>
                </label>
                <span className="text-sm text-slate-500">
                  {profanityFilter ? "On" : "Off"}
                </span>
              </div>
            </label>
          </div>

          <button
            type="button"
            className={clsx(
              "w-full rounded-xl px-6 py-4 text-lg font-semibold transition",
              isLoading
                ? "bg-slate-200 text-slate-500"
                : "bg-ink text-white hover:bg-slate-800"
            )}
            onClick={() => handleGenerate()}
            disabled={isLoading}
          >
            {isLoading ? "Forging..." : "Generate"}
          </button>

          {statusMessage && (
            <p className="text-sm text-amber-700">{statusMessage}</p>
          )}
        </div>

        <div className="card p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="badge">Result</p>
              <p className="text-sm text-slate-500">Seed: {seed || "—"}</p>
            </div>
            <div className="flex gap-2">
              <button
                type="button"
                className="rounded-lg border border-slate-200 px-3 py-2 text-sm font-semibold"
                onClick={handleCopy}
              >
                Copy
              </button>
              {isPro && (
                <button
                  type="button"
                  className="rounded-lg border border-slate-200 px-3 py-2 text-sm font-semibold"
                  onClick={handleDownload}
                >
                  Export .txt
                </button>
              )}
            </div>
          </div>
          <pre className="whitespace-pre-wrap rounded-xl bg-slate-50 p-4 text-sm text-slate-700 min-h-[200px]">
            {result || "Your generated content will appear here."}
          </pre>
          {isPro && seed && (
            <button
              type="button"
              className="rounded-lg border border-slate-200 px-3 py-2 text-sm font-semibold"
              onClick={() => handleGenerate(seed)}
            >
              {regenerateLabel} with same seed
            </button>
          )}
        </div>
      </section>

      <section className="space-y-6">
        <div className="card p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="badge">Account</p>
              <p className="text-sm text-slate-500">
                {sessionUserId ? "Signed in" : "Free tier"}
              </p>
            </div>
            {isPro && (
              <span className="rounded-full bg-emerald-100 px-3 py-1 text-xs font-semibold text-emerald-700">
                Pro
              </span>
            )}
          </div>

          {!sessionUserId && (
            <div className="space-y-3">
              <p className="text-sm text-slate-600">
                Sign in to unlock Pro features, exports, and history.
              </p>
              <input
                className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3"
                placeholder="you@example.com"
                value={email}
                onChange={(event) => setEmail(event.target.value)}
              />
              <button
                type="button"
                className="w-full rounded-xl bg-ink px-4 py-3 text-white font-semibold"
                onClick={handleLogin}
              >
                Send magic link
              </button>
            </div>
          )}

          {sessionUserId && !isPro && (
            <div className="space-y-3">
              <p className="text-sm text-slate-600">
                Upgrade to Pro for unlimited generations, exports, and history.
              </p>
              <button
                type="button"
                className="w-full rounded-xl bg-ember px-4 py-3 text-white font-semibold"
                onClick={handleUpgrade}
              >
                Upgrade to Pro ($2/month)
              </button>
            </div>
          )}

          {sessionUserId && (
            <button
              type="button"
              className="w-full rounded-xl border border-slate-200 px-4 py-3 font-semibold"
              onClick={async () => {
                await supabaseClient.auth.signOut();
              }}
            >
              Sign out
            </button>
          )}

          {isPro && (
            <button
              type="button"
              className="w-full rounded-xl border border-slate-200 px-4 py-3 font-semibold"
              onClick={handlePortal}
            >
              Manage subscription
            </button>
          )}
        </div>

        {isPro && (
          <div className="card p-6 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="badge">History</p>
                <p className="text-sm text-slate-500">Last 50 generations</p>
              </div>
            </div>
            <div className="space-y-3 max-h-[420px] overflow-auto">
              {history.length === 0 && (
                <p className="text-sm text-slate-500">
                  Your latest generations will appear here.
                </p>
              )}
              {history.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  className="w-full text-left rounded-xl border border-slate-100 bg-slate-50 p-3 hover:bg-slate-100"
                  onClick={() => {
                    setGeneratorType(item.type);
                    setTone(item.tone);
                    setSeed(item.seed);
                    setResult(item.content);
                  }}
                >
                  <p className="text-xs uppercase tracking-[0.2em] text-slate-500">
                    {item.type} · {item.tone}
                  </p>
                  <p className="text-sm text-slate-700">
                    {item.content}
                  </p>
                </button>
              ))}
            </div>
          </div>
        )}
      </section>
    </div>
  );
}